#include <Arduino.h>
#include <SPI.h>

// ================= กำหนดขาเชื่อมต่อไปยัง FPGA DE10-Lite =================
#define PIN_BLOCK_READY  4    // ขา D4  (GPIO 4)  <- รับสัญญาณ Interrupt จาก FPGA (PIN_V7)
#define PIN_SPI_CS       10   // ขา D10 (GPIO 10) -> ส่งสัญญาณเลือกชิป SPI_CS_N ไปยัง FPGA (PIN_W8)
#define PIN_SPI_MOSI     11   // ขา D11 (GPIO 11)
#define PIN_SPI_SCK      12   // ขา D13 (GPIO 12) -> ส่งสัญญาณนาฬิกา SPI_SCK ไปยัง FPGA (PIN_W9)
#define PIN_SPI_MISO     13   // ขา D12 (GPIO 13) <- รับข้อมูลเสียง SPI_MISO จาก FPGA (PIN_V8)

// ================= ตั้งค่าขนาดบล็อกและความเร็ว =================
#define BLOCK_SIZE       1024      // จำนวนตัวอย่างต่อบล็อก (N = 1024)
#define SERIAL_BAUD      921600    // ความเร็วส่งข้อมูลเข้าคอมพิวเตอร์
#define SPI_CLOCK_SPEED  4000000   // ความเร็วบัส SPI 4 MHz

SPIClass fspi(FSPI);
uint16_t rxBuffer[BLOCK_SIZE];
const uint8_t frameHeader[2] = {0xAA, 0x55};

// ตัวแปร Flag สำหรับรับสัญญาณจาก Hardware Interrupt (ต้องเป็น volatile)
volatile bool blockReadyFlag = false;

// ฟังก์ชัน Interrupt Service Routine (ISR) ทำงานบน RAM ความเร็วสูงทันทีที่ขา D4 มีขอบขาขึ้น
void IRAM_ATTR onFpgaBlockReady() {
  blockReadyFlag = true;
}

void setup() {
  Serial.begin(SERIAL_BAUD);

  pinMode(PIN_BLOCK_READY, INPUT);
  pinMode(PIN_SPI_CS, OUTPUT);
  digitalWrite(PIN_SPI_CS, HIGH);

  // เริ่มต้นบัส FSPI ของชิป ESP32-S3
  fspi.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI, PIN_SPI_CS);

  // ผูกขา PIN_BLOCK_READY เข้ากับ Hardware Interrupt เมื่อเกิดขอบขาขึ้น (RISING Edge)
  attachInterrupt(digitalPinToInterrupt(PIN_BLOCK_READY), onFpgaBlockReady, RISING);
}

void loop() {
  // ทำงานทันทีเมื่อได้รับสัญญาณ Interrupt จาก FPGA โดยไม่มีการใช้ delay()
  if (blockReadyFlag) {
    blockReadyFlag = false; // เคลียร์สถานะ Flag ทันทีเพื่อรอรับบล็อกถัดไป

    // ดึงข้อมูล 1024 ตัวอย่างจาก Block RAM ของ FPGA ผ่านฮาร์ดแวร์ FSPI
    fspi.beginTransaction(SPISettings(SPI_CLOCK_SPEED, MSBFIRST, SPI_MODE0));
    digitalWrite(PIN_SPI_CS, LOW);

    for (int i = 0; i < BLOCK_SIZE; i++) {
      rxBuffer[i] = fspi.transfer16(0x0000);
    }

    digitalWrite(PIN_SPI_CS, HIGH);
    fspi.endTransaction();

    // ส่ง Header (0xAA 0x55) ตามด้วยบล็อกข้อมูล Binary 2048 Bytes ออกทาง USB Serial
    Serial.write(frameHeader, 2);
    Serial.write((uint8_t*)rxBuffer, sizeof(rxBuffer));
  }
}