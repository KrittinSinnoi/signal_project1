library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- Ping-pong Block RAM (2 x 1024 words) + SPI slave (Mode 0, MSB first)
-- * I2S writes into one bank while the ESP32 reads the other completed bank
-- * SPI is oversampled with clk_50m (keep SCK <= ~8 MHz; 4 MHz is fine)
-- * MSB of word 0 is already on MISO when CS goes low (correct Mode 0 timing)
-- * block_ready: goes '1' when a bank is full, '0' when ESP32 pulls CS low
--   (or automatically after half a block, so the next rising edge is never lost)

entity bram_spi_slave is
    Port (
        clk_50m     : in  STD_LOGIC;
        reset_n     : in  STD_LOGIC;
        chord_code  : in  STD_LOGIC_VECTOR(3 downto 0);
        sample_12b  : in  STD_LOGIC_VECTOR(11 downto 0);
        sample_vld  : in  STD_LOGIC;
        spi_sck     : in  STD_LOGIC;
        spi_cs_n    : in  STD_LOGIC;
        spi_miso    : out STD_LOGIC;
        block_ready : out STD_LOGIC
    );
end bram_spi_slave;

architecture Behavioral of bram_spi_slave is
    -- 2048 x 16 dual-port RAM -> inferred as M9K blocks
    type ram_type is array (0 to 2047) of std_logic_vector(15 downto 0);
    signal ram       : ram_type;
    signal ram_we    : std_logic;
    signal ram_waddr : unsigned(10 downto 0);
    signal ram_raddr : unsigned(10 downto 0);
    signal ram_din   : std_logic_vector(15 downto 0);
    signal ram_q     : std_logic_vector(15 downto 0) := (others => '0');

    -- write side
    signal wr_bank   : std_logic := '0';
    signal wr_addr   : unsigned(9 downto 0) := (others => '0');
    signal done_bank : std_logic := '1';      -- last completely filled bank
    signal ready_reg : std_logic := '0';

    -- SPI side (synchronised to clk_50m)
    signal sck_sync  : std_logic_vector(2 downto 0) := (others => '0');
    signal cs_sync   : std_logic_vector(2 downto 0) := (others => '1');
    signal sck_fall  : std_logic;
    signal cs_fall   : std_logic;
    signal cs_s      : std_logic;

    signal rd_bank   : std_logic := '1';
    signal rd_addr   : unsigned(9 downto 0) := (others => '0');
    signal shift_reg : std_logic_vector(15 downto 0) := (others => '0');
    signal bit_cnt   : unsigned(3 downto 0) := (others => '0');
    signal first     : std_logic := '1';
begin
    ---------------------------------------------------------------------------
    -- RAM (no reset -> lets Quartus infer Block RAM)
    ---------------------------------------------------------------------------
    process(clk_50m)
    begin
        if rising_edge(clk_50m) then
            if ram_we = '1' then
                ram(to_integer(ram_waddr)) <= ram_din;
            end if;
            ram_q <= ram(to_integer(ram_raddr));
        end if;
    end process;

    ram_we    <= sample_vld;
    ram_din   <= chord_code & sample_12b;
    ram_waddr <= wr_bank & wr_addr;
    ram_raddr <= rd_bank & rd_addr;

    ---------------------------------------------------------------------------
    -- Write side: fill one bank, swap at 1024 samples
    ---------------------------------------------------------------------------
    process(clk_50m, reset_n)
    begin
        if reset_n = '0' then
            wr_bank   <= '0';
            wr_addr   <= (others => '0');
            done_bank <= '1';
            ready_reg <= '0';
        elsif rising_edge(clk_50m) then
            if sample_vld = '1' then
                if wr_addr = 1023 then
                    wr_addr   <= (others => '0');
                    done_bank <= wr_bank;        -- this bank is now complete
                    wr_bank   <= not wr_bank;
                    ready_reg <= '1';
                else
                    wr_addr <= wr_addr + 1;
                    if wr_addr = 511 then
                        ready_reg <= '0';        -- auto-clear if ESP32 missed it
                    end if;
                end if;
            end if;
            if cs_fall = '1' then
                ready_reg <= '0';                -- ESP32 started reading
            end if;
        end if;
    end process;
    block_ready <= ready_reg;

    ---------------------------------------------------------------------------
    -- SPI slave, Mode 0: master samples on rising SCK, we shift on falling SCK
    ---------------------------------------------------------------------------
    process(clk_50m, reset_n)
    begin
        if reset_n = '0' then
            sck_sync <= (others => '0');
            cs_sync  <= (others => '1');
        elsif rising_edge(clk_50m) then
            sck_sync <= sck_sync(1 downto 0) & spi_sck;
            cs_sync  <= cs_sync(1 downto 0)  & spi_cs_n;
        end if;
    end process;

    cs_s     <= cs_sync(1);
    sck_fall <= sck_sync(2) and not sck_sync(1);
    cs_fall  <= cs_sync(2)  and not cs_sync(1);

    process(clk_50m, reset_n)
    begin
        if reset_n = '0' then
            rd_bank   <= '1';
            rd_addr   <= (others => '0');
            shift_reg <= (others => '0');
            bit_cnt   <= (others => '0');
            first     <= '1';
        elsif rising_edge(clk_50m) then
            if cs_s = '1' then
                -- idle: point at word 0 of the last completed bank and preload it
                rd_bank   <= done_bank;
                rd_addr   <= (others => '0');
                shift_reg <= ram_q;
                bit_cnt   <= (others => '0');
                first     <= '1';
            else
                if first = '1' then
                    rd_addr <= to_unsigned(1, 10);   -- prefetch word 1
                    first   <= '0';
                end if;

                if sck_fall = '1' then
                    if bit_cnt = 15 then
                        shift_reg <= ram_q;          -- next word
                        rd_addr   <= rd_addr + 1;    -- prefetch the one after
                        bit_cnt   <= (others => '0');
                    else
                        shift_reg <= shift_reg(14 downto 0) & '0';
                        bit_cnt   <= bit_cnt + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    spi_miso <= shift_reg(15);
end Behavioral;
