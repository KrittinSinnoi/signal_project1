library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity chord_encoder is
    Port (
        sw         : in  STD_LOGIC_VECTOR(4 downto 0);
        chord_code : out STD_LOGIC_VECTOR(3 downto 0)
    );
end chord_encoder;

architecture Behavioral of chord_encoder is
begin
    process(sw)
    begin
        if    sw(0) = '1' then chord_code <= "0001"; -- C
        elsif sw(1) = '1' then chord_code <= "0010"; -- D
        elsif sw(2) = '1' then chord_code <= "0011"; -- E
        elsif sw(3) = '1' then chord_code <= "0100"; -- F
        elsif sw(4) = '1' then chord_code <= "0101"; -- G
        else                   chord_code <= "0000"; -- Auto
        end if;
    end process;
end Behavioral;