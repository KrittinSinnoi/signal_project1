library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity final_project_signal_vhdl is
    Port (
        clk_50m     : in  STD_LOGIC;
        reset_n     : in  STD_LOGIC;
        sw          : in  STD_LOGIC_VECTOR(4 downto 0);
        
        i2s_sck     : out STD_LOGIC;
        i2s_ws      : out STD_LOGIC;
        i2s_sd      : in  STD_LOGIC;
        
        spi_sck     : in  STD_LOGIC;
        spi_cs_n    : in  STD_LOGIC;
        spi_miso    : out STD_LOGIC;
        block_ready : out STD_LOGIC
    );
end final_project_signal_vhdl;

architecture Structural of final_project_signal_vhdl is

    -- Component Declarations
    component chord_encoder
        Port (
            sw         : in  STD_LOGIC_VECTOR(4 downto 0);
            chord_code : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component i2s_rx
        Port (
            clk_50m    : in  STD_LOGIC;
            reset_n    : in  STD_LOGIC;
            i2s_sd     : in  STD_LOGIC;
            i2s_sck    : out STD_LOGIC;
            i2s_ws     : out STD_LOGIC;
            sample_12b : out STD_LOGIC_VECTOR(11 downto 0);
            sample_vld : out STD_LOGIC
        );
    end component;

    component bram_spi_slave
        Port (
            clk_50m     : in  STD_LOGIC;
            reset_n     : in  STD_LOGIC;
            chord_code  : in  STD_LOGIC_VECTOR(3 downto 0);
            sample_12b  : in  STD_LOGIC_VECTOR(11 downto 0);
            sample_vld  : in  STD_LOGIC;
            spi_sck     : in  STD_LOGIC;
            spi_cs_n    : in  STD_LOGIC;
            spi_miso    : out STD_LOGIC;
            block_ready : out STD_LOGIC
        );
    end component;

    -- Internal Signals
    signal sig_chord_code : STD_LOGIC_VECTOR(3 downto 0);
    signal sig_sample_12b : STD_LOGIC_VECTOR(11 downto 0);
    signal sig_sample_vld : STD_LOGIC;

begin

    Inst_chord_encoder: chord_encoder
        Port map (
            sw         => sw,
            chord_code => sig_chord_code
        );

    Inst_i2s_rx: i2s_rx
        Port map (
            clk_50m    => clk_50m,
            reset_n    => reset_n,
            i2s_sd     => i2s_sd,
            i2s_sck    => i2s_sck,
            i2s_ws     => i2s_ws,
            sample_12b => sig_sample_12b,
            sample_vld => sig_sample_vld
        );

    Inst_bram_spi_slave: bram_spi_slave
        Port map (
            clk_50m     => clk_50m,
            reset_n     => reset_n,
            chord_code  => sig_chord_code,
            sample_12b  => sig_sample_12b,
            sample_vld  => sig_sample_vld,
            spi_sck     => spi_sck,
            spi_cs_n    => spi_cs_n,
            spi_miso    => spi_miso,
            block_ready => block_ready
        );

end Structural;