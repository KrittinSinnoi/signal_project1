library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity i2s_rx is
    Port (
        clk_50m    : in  STD_LOGIC;
        reset_n    : in  STD_LOGIC;
        i2s_sd     : in  STD_LOGIC;
        i2s_sck    : out STD_LOGIC;
        i2s_ws     : out STD_LOGIC;
        sample_12b : out STD_LOGIC_VECTOR(11 downto 0);
        sample_vld : out STD_LOGIC
    );
end i2s_rx;

architecture Behavioral of i2s_rx is
    constant BCLK_DIV : integer := 49;
    signal div_cnt    : integer range 0 to BCLK_DIV - 1 := 0;
    signal bclk_reg   : std_logic := '0';
    signal bit_idx    : integer range 0 to 63 := 0;
    signal shift_reg  : std_logic_vector(23 downto 0) := (others => '0');
begin
    process(clk_50m, reset_n)
    begin
        if reset_n = '0' then
            div_cnt    <= 0;
            bclk_reg   <= '0';
            bit_idx    <= 0;
            shift_reg  <= (others => '0');
            sample_12b <= (others => '0');
            sample_vld <= '0';
        elsif rising_edge(clk_50m) then
            sample_vld <= '0';
            
            if div_cnt = BCLK_DIV - 1 then
                div_cnt <= 0;
            else
                div_cnt <= div_cnt + 1;
            end if;

            if div_cnt = (BCLK_DIV / 2) then
                bclk_reg <= '1';
                if bit_idx >= 1 and bit_idx <= 24 then
                    shift_reg(24 - bit_idx) <= i2s_sd;
                end if;
                
            elsif div_cnt = BCLK_DIV - 1 then
                bclk_reg <= '0';
                if bit_idx = 25 then
                    sample_12b <= shift_reg(23) & shift_reg(21 downto 11);
                    sample_vld <= '1';
                end if;

                if bit_idx = 63 then
                    bit_idx <= 0;
                else
                    bit_idx <= bit_idx + 1;
                end if;
            end if;
        end if;
    end process;

    i2s_sck <= bclk_reg;
    i2s_ws  <= '0' when bit_idx < 32 else '1';
end Behavioral;